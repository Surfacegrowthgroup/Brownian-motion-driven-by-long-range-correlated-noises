% 清除工作区和命令窗口，避免已有变量干扰
clear; clc;

% 定义不同的 theta 值
theta_list = [0, 0.05, 0.15, 0.25, 0.35, 0.45];
letter_list = {'(a)', '(b)', '(c)', '(d)', '(e)', '(f)'}; % 序号列表

% 创建画布
figure('Units', 'inches', 'Position', [0 0 8 6]);

% 调整观测区间
N = 100000; % 总时间
dt = 0.01;        % 时间步长
max_lag = N/dt;   % 时间步数

% 固定的参数值
Lambda = 30;
a = 6.0;
B = 2.0;

% 遍历不同的 theta 值
for idx = 1:length(theta_list)
    % 初始化向量
    x = zeros(1, max_lag);

    % 根据 theta 值选择噪声生成方法
    if theta_list(idx) == 0
        % 当 theta=0 时，使用高斯白噪声
        eta = sqrt(dt) * randn(1, max_lag);
        eta_x = eta; % 统一变量名
    else
        % 当 theta>0 时，使用分数阶高斯噪声
        eta_x = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
    end

    % 计算 x 序列
    for i = 2:max_lag
        x(i) = x(i - 1) + eta_x(i - 1);
    end
    
    % 生成与x长度匹配的时间序列
    t_vals = 0:dt:(max_lag-1)*dt;  

    % 创建子图
    subplot(2, 3, idx);

    % 绘制子图
    plot(t_vals, x);

    % 添加标题，显示当前 theta 值，设置字体为新罗马体、斜体
    title(['\theta = ', num2str(theta_list(idx))], 'FontName', 'Times New Roman', 'FontAngle', 'italic');

    % 添加坐标轴标签，设置字体为新罗马体、斜体、大小11
    xlabel('t', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
    ylabel('x', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

    % 设置网格线，方便查看数据分布
    grid on;
    grid minor;
    set(gca, 'GridLineStyle', ':');

    % 设置坐标轴范围，使图形展示更合理
    xlim([min(t_vals), max(t_vals)]);
    ylim([min(x), max(x)]);
    
    % 在左上角添加序号标注
    label = letter_list{idx};
    
    % 计算左上角位置（归一化坐标）
    x_pos = 0.05; % 左侧5%边距
    y_pos = 0.95; % 顶部5%边距（从底部向上计算）
    
    % 转换为轴坐标并标注
    ax = gca;
    xlims = xlim;
    ylims = ylim;
    x_coord = xlims(1) + x_pos * (xlims(2) - xlims(1));
    y_coord = ylims(1) + y_pos * (ylims(2) - ylims(1));
    
    text(x_coord, y_coord, label, ...
        'FontName', 'Times New Roman', 'FontSize', 12, ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top'); % 左对齐，顶部对齐
end

% 调整子图布局，让图形更紧凑美观
try
    tight_subplot(2, 3, 0.05, 0.05, 0.05);
catch ME
    warning('tight_subplot 函数未找到，子图布局可能不够紧凑。');
end

% 提高图形清晰度
set(gcf, 'Renderer', 'painters');
