% 清除工作区和命令窗口，避免已有变量干扰
clear; clc;

% 定义不同的 theta 值
theta_list = [0, 0.05, 0.15, 0.25, 0.35, 0.45];
letter_list = {'(a)', '(b)', '(c)', '(d)', '(e)', '(f)'}; % 序号列表

% 调整观测区间，即模拟的时间步数
N = 1000; 
dt = 0.01;
max_lag = N / dt;

% 固定的参数值
Lambda = 30;
a = 6.0;
B = 2.0;

rep = 5000; % 重复次数

% 存储所有 theta 值的概率密度拟合曲线数据
all_pdf_fit = cell(length(theta_list), 1);

% 第一张图：分布统计子图
figure('Units', 'inches', 'Position', [0 0 8 6]);
subplot(1,1,1); % 先创建主图

% 遍历不同的 theta 值
for idx = 1:length(theta_list)
    all_x = zeros(rep, max_lag); % 存储每次重复的位移数据

    for repeat_idx = 1:rep
        % 初始化位置向量 x，长度为 max_lag，初始值全为 0
        x = zeros(1, max_lag);

        % 根据 theta 值选择噪声生成方法
        if theta_list(idx) == 0
            eta = sqrt(dt) * randn(1, max_lag);
        else
            eta = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
        end

        % 计算位置序列 x
        for i = 2 : max_lag
            x(i) = x(i - 1) + eta(i - 1);
        end

        all_x(repeat_idx, :) = x;
    end

    % 直接使用所有数据
    sampled_x = all_x(:);

    % 创建子图
    subplot(2, 3, idx);

    % 手动指定分组边界
    bin_edges = linspace(min(sampled_x), max(sampled_x), 10000); 
    [n, edges] = histcounts(sampled_x, bin_edges, 'Normalization', 'pdf');
    bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    bar(bin_centers, n, 'FaceColor', 'b');

    % 应用高斯核平滑
    kernel_size = 21; % 高斯核窗口大小
    sigma = 3; % 高斯核标准差
    n_smoothed = gaussian_smooth(n, kernel_size, sigma);

    % 绘制平滑曲线
    hold on;
    plot(bin_centers, n_smoothed, 'r', 'LineWidth', 2);
    hold off;

    % 存储当前 theta 值的概率密度拟合曲线数据
    all_pdf_fit{idx} = [bin_centers; n_smoothed];

    % 设置子图的标题
    title(['\theta = ', num2str(theta_list(idx))], 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

    % 添加坐标轴标签
    xlabel('x', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
    ylabel('pdf', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

    % 显示网格线
    grid on;
    grid minor;
    box on;
    set(gca, 'GridLineStyle', ':');
    
    % 在左下角添加序号标注
    label = letter_list{idx};
    x_pos = 0.05;  % 左侧5%边距
    y_pos = 0.05;  % 底部5%边距
    ax = gca;
    xlims = xlim;
    ylims = ylim;
    x_coord = xlims(1) + x_pos * (xlims(2) - xlims(1));
    y_coord = ylims(1) + y_pos * (ylims(2) - ylims(1));
    text(x_coord, y_coord, label, ...
        'FontName', 'Times New Roman', 'FontSize', 12, ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
end

% 提高图形的渲染质量
set(gcf, 'Renderer', 'painters');

% 第二张图：概率密度曲线
figure;
colors = hsv(length(theta_list)-1); % 生成颜色（跳过θ=0）
legend_entries = cell(length(theta_list)-1, 1);

for idx = 2:length(theta_list)  % 从idx=2开始（跳过θ=0）
    x_fit = all_pdf_fit{idx}(1, :);
    y_fit = all_pdf_fit{idx}(2, :);
    plot(x_fit, y_fit, 'Color', colors(idx-1, :), 'LineWidth', 2);
    hold on;
    legend_entries{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

hold off;

% 获取当前坐标轴对象
ax = gca;

% 设置横坐标范围
xlim([-1e4, 1e4]);

% 设置坐标轴标签
xlims = xlim;
ylims = ylim;
xlabel('x', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.075 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

% 添加图例
legend(legend_entries, 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

% 显示网格线
grid on;
grid minor;
box off;
set(ax, 'GridLineStyle', ':');

% 处理纵坐标科学计数法指数显示
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('x10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 处理横坐标科学计数法指数显示
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('x10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 设置坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

% 定义高斯核平滑函数
function smoothed = gaussian_smooth(data, kernel_size, sigma)
    kernel = normpdf(-(kernel_size-1)/2:(kernel_size-1)/2, 0, sigma);
    kernel = kernel / sum(kernel);
    smoothed = conv(data, kernel, 'same');
end
