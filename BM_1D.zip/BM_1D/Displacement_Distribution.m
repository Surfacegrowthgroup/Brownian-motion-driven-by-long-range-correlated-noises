clear; clc;

% 定义不同的 theta 值
theta_list = [0, 0.05, 0.15, 0.25, 0.35, 0.45];

% 调整观测区间，即模拟的时间步数
N = 1000; 
dt = 0.01;
max_lag = N / dt;

% 固定的参数值
Lambda = 30;
a = 6.0;
B = 2.0;

num_repeats = 5000; % 重复次数

% 存储所有 theta 值的概率密度拟合曲线数据
all_pdf_fit = cell(length(theta_list), 1);

% 遍历不同的 theta 值
for idx = 1:length(theta_list)
    all_x = zeros(num_repeats, max_lag); % 存储每次重复的位移数据

    for repeat_idx = 1:num_repeats
        % 初始化位置向量 x，长度为 max_lag，初始值全为 0
        x = zeros(1, max_lag);

        % 根据 theta 值选择噪声生成方法
        if theta_list(idx) == 0
            eta = sqrt(dt) * randn(1, max_lag);
        else
            eta = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
        end

        % 计算位置序列 x
        for i = 2 : max_lag
            x(i) = x(i - 1) + eta(i - 1);
        end

        all_x(repeat_idx, :) = x;
    end

    % 直接使用所有数据
    sampled_x = all_x(:);

    % 手动指定分组边界
    bin_edges = linspace(min(sampled_x), max(sampled_x), 10000); 
    [n, edges] = histcounts(sampled_x, bin_edges, 'Normalization', 'pdf');
    bin_centers = (edges(1:end-1) + edges(2:end)) / 2;

    % 应用高斯核平滑
    kernel_size = 21; % 高斯核窗口大小
    sigma = 3; % 高斯核标准差
    n_smoothed = gaussian_smooth(n, kernel_size, sigma);

    % 存储当前 theta 值的概率密度拟合曲线数据
    all_pdf_fit{idx} = [bin_centers; n_smoothed];
end

% 第二张图：概率密度曲线（跳过θ=0）
figure('Units', 'inches', 'Position', [0 0 8 6]);

% 定义标记形状和颜色
markers = {'o', 's', '^', 'd', 'v'}; % 圆形/方形/上三角/菱形/下三角（5个形状对应5条曲线）
colors = {
    [0.8 0 0],        % 暗红
    [0 0 0.8],        % 深蓝
    [0 0.5 0],        % 暗绿
    [0.5 0 0.5],      % 紫红
    [0 0.75 0.75]};   % 青色

% 存储图例句柄
h_legend = [];

% 设置标记间隔，避免过于密集
marker_interval = 200;

for idx = 2:length(theta_list)  % 从idx=2开始（跳过θ=0）
    x_fit = all_pdf_fit{idx}(1, :);
    y_fit = all_pdf_fit{idx}(2, :);
    
    % 计算中心区域的数据范围（用于图例显示）
    center_idx = abs(x_fit) < 1000; % 选择x在[-1000, 1000]范围内的数据点
    x_center = x_fit(center_idx);
    y_center = y_fit(center_idx);
   
    legend_idx = round(length(x_center)/2); 
    
    % 绘制完整的曲线（不带标记）
    line_handle = plot(x_fit, y_fit, 'Color', colors{idx-1}, 'LineWidth', 1.5);
    hold on;
    
    % 在中间位置添加一个代表性标记（用于图例）
    marker_handle = plot(x_center(legend_idx), y_center(legend_idx), ...
        'Marker', markers{idx-1}, ...
        'MarkerSize', 10, ...
        'MarkerFaceColor', colors{idx-1}, ...
        'MarkerEdgeColor', 'k', ...
        'LineStyle', 'none', ...
        'Color', colors{idx-1}); % 确保颜色一致
    
    % 在整个曲线上按间隔添加标记（显示在图上）
    marker_indices = 1:marker_interval:length(x_fit);
    plot(x_fit(marker_indices), y_fit(marker_indices), ...
        'Marker', markers{idx-1}, ...
        'MarkerSize', 6, ...
        'MarkerFaceColor', colors{idx-1}, ...
        'MarkerEdgeColor', 'k', ...
        'LineStyle', 'none');
    
    % 将标记点句柄添加到图例句柄数组
    h_legend = [h_legend, marker_handle];
end

hold off;

% 获取当前坐标轴对象
ax = gca;

% 设置横坐标范围
xlim([-1e4, 1e4]);

% 设置坐标轴标签
xlims = xlim;
ylims = ylim;
xlabel('x', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.075 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

% 创建图例标签
legend_labels = cell(length(theta_list)-1, 1);
for idx = 2:length(theta_list)
    legend_labels{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

% 添加图例（只显示标记点）
legend(h_legend, legend_labels, ...
    'FontName', 'Times New Roman', ...
    'FontAngle', 'italic', ...
    'FontSize', 11, ...
    'Location', 'best', ...
    'Box', 'off');

% 网格线
grid on;
grid minor;
box off;
set(ax, 'GridLineStyle', ':');

% 处理纵坐标科学计数法指数显示
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('×10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 处理横坐标科学计数法指数显示
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('×10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 设置坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

% 提高图形的渲染质量
set(gcf, 'Renderer', 'painters');

% 定义高斯核平滑函数
function smoothed = gaussian_smooth(data, kernel_size, sigma)
    kernel = normpdf(-(kernel_size-1)/2:(kernel_size-1)/2, 0, sigma);
    kernel = kernel / sum(kernel);
    smoothed = conv(data, kernel, 'same');
end