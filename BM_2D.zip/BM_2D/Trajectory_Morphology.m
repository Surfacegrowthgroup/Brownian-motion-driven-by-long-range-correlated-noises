% 定义不同的 theta 值
theta_list = [ 0.0, 0.05, 0.15, 0.25, 0.35, 0.45];
letter_list = {'(a)', '(b)', '(c)', '(d)', '(e)', '(f)'}; % 序号列表

% 创建画布
tiledlayout(2,3);

% 调整观测区间
N = 100000; % 总时间
dt = 0.01; % 时间步长
max_lag = N / dt; % 时间步数，适当减小避免内存问题

% 固定的参数值
Lambda = 30;
a = 6.0;
B = 2.0;

% 遍历不同的 theta 值
for idx = 1:length(theta_list)
    % 初始化向量
    x = zeros(1, max_lag);
    y = zeros(1, max_lag);

    % 根据 theta 值选择噪声生成方法
    if theta_list(idx) == 0
        % 当 theta=0 时，使用高斯白噪声
        eta_x = sqrt(dt) * randn(1, max_lag);
        eta_y = sqrt(dt) * randn(1, max_lag);
    else
        % 生成分数阶高斯噪声
        eta_x = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
        eta_y = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
    end

    % 计算 x 和 y 序列
    for i = 2:max_lag
        x(i) = x(i - 1) + eta_x(i - 1);
        y(i) = y(i - 1) + eta_y(i - 1);
    end

    % 选取间隔为 10 的数据点
    step = 10;
    x_sub = x(1:step:end);
    y_sub = y(1:step:end);

    % 创建子图
    nexttile;

    % 绘制子图
    plot(x_sub, y_sub);

    % 设置子图的标题，显示当前的 theta 值
    title(['\theta = ', num2str(theta_list(idx))], 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
    
    % 添加坐标轴标签
    xlabel('x', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
    ylabel('y', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

    % 设置坐标轴范围
    xlim([min(x_sub), max(x_sub)]);
    ylim([min(y_sub), max(y_sub)]);

    % 设置网格线
    grid on;
    grid minor;
    box on;
    set(gca, 'GridLineStyle', ':');
    
    % 在左下角添加序号标注
    label = letter_list{idx};
    
    % 获取当前子图的坐标范围
    ax = gca;
    xlims = xlim;
    ylims = ylim;
    
    % 计算左下角位置（使用归一化坐标）
    x_pos = 0.05;  % 左侧5%边距
    y_pos = 0.05;  % 底部5%边距
    
    % 将归一化坐标转换为数据坐标
    x_coord = xlims(1) + x_pos * (xlims(2) - xlims(1));
    y_coord = ylims(1) + y_pos * (ylims(2) - ylims(1));
    
    % 添加文本标注（新罗马字体，左对齐，底部对齐）
    text(x_coord, y_coord, label, ...
        'FontName', 'Times New Roman', 'FontSize', 12, ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
end

% 提高图形清晰度
set(gcf, 'Renderer', 'painters');
