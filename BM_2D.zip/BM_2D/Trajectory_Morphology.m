
clear; clc;

% 定义不同的 theta 值
theta_list = [0.0, 0.05, 0.15, 0.25, 0.35, 0.45];
letter_list = {'(a)', '(b)', '(c)', '(d)', '(e)', '(f)'}; % 序号列表

% 调整观测区间
N = 100000; % 总时间
dt = 0.01; % 时间步长
max_lag = N / dt; % 时间步数

% 固定的参数值
Lambda = 30;
a = 6.0;
B = 2.0;

% 设置图形参数
marker_size = 1; % 点的大小
line_width = 0.5; % 线宽

% 创建独立的图形窗口
for idx = 1:length(theta_list)
  
    figure('Units', 'inches', 'Position', [0 0 5 5]); % 5x5英寸的正方形
    
    % 初始化向量
    x = zeros(1, max_lag);
    y = zeros(1, max_lag);

    % 根据 theta 值选择噪声生成方法
    if theta_list(idx) == 0
        % 当 theta=0 时，使用高斯白噪声
        eta_x = sqrt(dt) * randn(1, max_lag);
        eta_y = sqrt(dt) * randn(1, max_lag);
    else
        % 生成分数阶高斯噪声
        eta_x = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
        eta_y = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
    end

    % 计算 x 和 y 序列
    for i = 2:max_lag
        x(i) = x(i - 1) + eta_x(i - 1);
        y(i) = y(i - 1) + eta_y(i - 1);
    end

    % 选取间隔为 10 的数据点
    step = 10;
    x_sub = x(1:step:end);
    y_sub = y(1:step:end);

    % 绘制轨迹
    plot(x_sub, y_sub, 'k', 'LineWidth', line_width);
    
    % 确保图形区域是正方形
    axis equal;
    
    % 设置子图的标题，显示当前的 theta 值
    title(['\theta = ', num2str(theta_list(idx))], ...
        'FontName', 'Times New Roman', ...
        'FontAngle', 'italic', ...
        'FontSize', 12, ...
        'FontWeight', 'normal');
    
    % 添加坐标轴标签
    xlabel('x', ...
        'FontName', 'Times New Roman', ...
        'FontAngle', 'italic', ...
        'FontSize', 12);
    ylabel('y', ...
        'FontName', 'Times New Roman', ...
        'FontAngle', 'italic', ...
        'FontSize', 12);

    % 设置网格线
    grid off;
    grid minor;
    box on;
    set(gca, 'GridLineStyle', ':');
    
    % 设置坐标轴字体
    set(gca, 'FontName', 'Times New Roman', 'FontSize', 11);
    
    % 在左上角添加序号标注
    label = letter_list{idx};
    
    % 获取当前子图的坐标范围
    ax = gca;
    xlims = xlim;
    ylims = ylim;
    
    % 计算左上角位置
    x_pos = 0.05;  % 左侧5%边距
    y_pos = 0.95;  % 顶部5%边距
    
    % 将归一化坐标转换为数据坐标
    x_coord = xlims(1) + x_pos * (xlims(2) - xlims(1));
    y_coord = ylims(1) + y_pos * (ylims(2) - ylims(1));
    
    % 添加文本标注
    text(x_coord, y_coord, label, ...
        'FontName', 'Times New Roman', ...
        'FontSize', 14, ...
        'FontWeight', 'bold', ...
        'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'top');
    
    % 提高图形清晰度
    set(gcf, 'Renderer', 'painters');
    
end

