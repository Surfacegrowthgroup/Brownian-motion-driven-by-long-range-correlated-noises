function eta = fast_fractional_gaussian_noise_matlab(theta, N, Lambda, a, B)
    u = zeros(1,Lambda);
    r = zeros(1,Lambda);
    W = zeros(1,Lambda);
    for n = 1:Lambda
        u(n) = a*(B^(-n));
        r(n) = exp(-u(n));
        Wn_sq = (12*(1 - r(n)^2)/gamma(2 - 2*theta))*((B^(0.5 - theta) - B^(theta - 0.5)))*(u(n)^(1 - 2*theta));
        if Wn_sq < 0
            Wn_sq = 0;
        end
        W(n) = sqrt(Wn_sq);
    end
    zeta = rand(Lambda,N);
    X = zeros(Lambda,N);
    for n = 1:Lambda
        rn = r(n);
        X(n,1) = (1 - rn^2)^(-0.5)*(zeta(n,1) - 0.5);
        for i = 2:N
            X(n,i) = rn*X(n,i-1) + (zeta(n,i) - 0.5);
        end
    end
    eta = zeros(1,N);
    for n = 1:Lambda
        eta = eta + W(n)*X(n,:);
    end
end