clear; clc;

% 定义不同的 theta 值
theta_list = [0, 0.05, 0.15, 0.25, 0.35, 0.45];

% 调整观测区间，即模拟的时间步数
N = 1000; 
dt = 0.01;
max_lag = N / dt;

% 固定的参数值
Lambda = 30;
a = 6.0;
B = 2.0;

num_repeats = 5000; % 重复次数

% 存储所有 theta 值的概率密度拟合曲线数据
all_pdf_fit = cell(length(theta_list), 1);
all_x_pdf = cell(length(theta_list), 1);
all_y_pdf = cell(length(theta_list), 1);
all_angle_pdf = cell(length(theta_list), 1);
all_x_data = cell(length(theta_list), 1);
all_y_data = cell(length(theta_list), 1);
all_angle_data = cell(length(theta_list), 1);

%% 模拟并存储数据
fprintf('正在模拟数据...\n');
for idx = 1:length(theta_list)
    all_r = zeros(num_repeats, max_lag); % 存储每次重复的位移距离
    all_x = zeros(num_repeats, max_lag); % 存储每次重复的x坐标
    all_y = zeros(num_repeats, max_lag); % 存储每次重复的y坐标
    
    for repeat_idx = 1:num_repeats
        % 初始化位置向量
        x = zeros(1, max_lag);
        y = zeros(1, max_lag);
        
        % 根据 theta 值选择噪声生成方法
        if theta_list(idx) == 0
            eta_x = sqrt(dt) * randn(1, max_lag);
            eta_y = sqrt(dt) * randn(1, max_lag);
        else
            eta_x = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
            eta_y = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
        end

        % 计算位置序列
        for i = 2 : max_lag
            x(i) = x(i - 1) + eta_x(i - 1);
            y(i) = y(i - 1) + eta_y(i - 1);
        end
        
        % 计算距离并存储
        all_r(repeat_idx, :) = sqrt(x.^2 + y.^2);
        all_x(repeat_idx, :) = x;
        all_y(repeat_idx, :) = y;
    end
    
    % 存储所有模拟数据
    all_x_data{idx} = all_x(:);
    all_y_data{idx} = all_y(:);
    
    % 处理距离数据并存储拟合曲线
    sampled_r = all_r(:);
    bin_edges = linspace(min(sampled_r), max(sampled_r), 10000); 
    [n, edges] = histcounts(sampled_r, bin_edges, 'Normalization', 'pdf');
    bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    kernel_size = 21; sigma = 3;
    n_smoothed = gaussian_smooth(n, kernel_size, sigma);
    all_pdf_fit{idx} = [bin_centers; n_smoothed];
end
fprintf('数据模拟完成！\n');

%% 定义标记形状和颜色
markers = {'o', 's', '^', 'd', 'v'}; % 圆形/方形/上三角/菱形/下三角（5个形状对应5条曲线）
colors = {
    [0.8 0 0],        % 暗红
    [0 0 0.8],        % 深蓝
    [0 0.5 0],        % 暗绿
    [0.5 0 0.5],      % 紫红
    [0 0.75 0.75]};   % 青色

% 标记间隔
marker_interval = 200;

%% 图1：总位移r的概率密度曲线（跳过θ=0）
fprintf('正在绘制总位移r的概率密度曲线...\n');
figure('Units', 'inches', 'Position', [0 0 8 6]);

% 存储图例句柄
h_legend = [];

for idx = 2:length(theta_list)  % 从idx=2开始（θ=0.05到0.45）
     x_fit = all_pdf_fit{idx}(1, :);
    y_fit = all_pdf_fit{idx}(2, :);
    
    % 计算中心区域的数据范围（用于图例显示）
    center_idx = abs(x_fit) < 1000; % 选择x在[-1000, 1000]范围内的数据点
    x_center = x_fit(center_idx);
    y_center = y_fit(center_idx);
    
    % 获取图例位置附近的数据点（中间区域）
    legend_idx = round(length(x_center)/2); % 取中间位置
    
    % 绘制完整的曲线（不带标记）
    line_handle = plot(x_fit, y_fit, 'Color', colors{idx-1}, 'LineWidth', 1.5);
    hold on;
    
    % 在中间位置添加一个代表性标记
    marker_handle = plot(x_center(legend_idx), y_center(legend_idx), ...
        'Marker', markers{idx-1}, ...
        'MarkerSize', 10, ...
        'MarkerFaceColor', colors{idx-1}, ...
        'MarkerEdgeColor', 'k', ...
        'LineStyle', 'none', ...
        'Color', colors{idx-1}); % 确保颜色一致
    
    % 在整个曲线上按间隔添加标记（显示在图上）
    marker_indices = 1:marker_interval:length(x_fit);
    plot(x_fit(marker_indices), y_fit(marker_indices), ...
        'Marker', markers{idx-1}, ...
        'MarkerSize', 6, ...
        'MarkerFaceColor', colors{idx-1}, ...
        'MarkerEdgeColor', 'k', ...
        'LineStyle', 'none');
    
    % 将标记点句柄添加到图例句柄数组
    h_legend = [h_legend, marker_handle];
end

hold off;

% 获取当前坐标轴对象
ax = gca;

% 设置横坐标范围
xlim([0, 1e4]);

% 设置坐标轴标签
xlims = xlim;
ylims = ylim;
xlabel('r', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.1 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

% 创建图例标签
legend_labels = cell(length(theta_list)-1, 1);
for idx = 2:length(theta_list)
    legend_labels{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

% 添加图例（只显示标记点）
legend(h_legend, legend_labels, ...
    'FontName', 'Times New Roman', ...
    'FontAngle', 'italic', ...
    'FontSize', 11, ...
    'Location', 'best', ...
    'Box', 'off');

% 网格线
grid on; grid minor; box off;
set(ax, 'GridLineStyle', ':');

% 处理科学计数法
% 纵坐标
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('×10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 横坐标
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('×10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 11, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

% 提高图形质量
set(gcf, 'Renderer', 'painters');
title('Total Displacement r Probability Density', 'FontName', 'Times New Roman', 'FontSize', 12);

%% 计算x和y分量的概率密度
fprintf('正在计算x和y分量的概率密度...\n');
for idx = 2:length(theta_list)
    % 计算x分量的概率密度
    sampled_x = all_x_data{idx};
    bin_edges_x = linspace(min(sampled_x), max(sampled_x), 10000);
    [n_x, edges_x] = histcounts(sampled_x, bin_edges_x, 'Normalization', 'pdf');
    bin_centers_x = (edges_x(1:end-1) + edges_x(2:end)) / 2;
    n_smoothed_x = gaussian_smooth(n_x, kernel_size, sigma);
    all_x_pdf{idx} = [bin_centers_x; n_smoothed_x];
    
    % 计算y分量的概率密度
    sampled_y = all_y_data{idx};
    bin_edges_y = linspace(min(sampled_y), max(sampled_y), 10000);
    [n_y, edges_y] = histcounts(sampled_y, bin_edges_y, 'Normalization', 'pdf');
    bin_centers_y = (edges_y(1:end-1) + edges_y(2:end)) / 2;
    n_smoothed_y = gaussian_smooth(n_y, kernel_size, sigma);
    all_y_pdf{idx} = [bin_centers_y; n_smoothed_y];
end

%% 图2：x分量的概率密度曲线（跳过θ=0）
fprintf('正在绘制x方向位移的概率密度曲线...\n');
figure('Units', 'inches', 'Position', [0 0 8 6]);

% 存储图例句柄
h_legend = [];

for idx = 2:length(theta_list)
    x_fit = all_x_pdf{idx}(1, :);
    y_fit = all_x_pdf{idx}(2, :);
    
    % 绘制完整的曲线（不带标记）
    plot(x_fit, y_fit, 'Color', colors{idx-1}, 'LineWidth', 1.5);
    hold on;
    
    % 在整个曲线上按间隔添加标记
    marker_indices = 1:marker_interval:length(x_fit);
    marker_handle = plot(x_fit(marker_indices), y_fit(marker_indices), ...
        'Marker', markers{idx-1}, ...
        'MarkerSize', 6, ...
        'MarkerFaceColor', colors{idx-1}, ...
        'MarkerEdgeColor', 'k', ...
        'LineStyle', 'none');
    
    % 将标记点句柄添加到图例句柄数组
    h_legend = [h_legend, marker_handle];
end

hold off;

% 获取当前坐标轴对象
ax = gca;

% 设置横坐标范围
xlim([-1e4, 1e4]);

% 设置坐标轴标签
xlims = xlim;
ylims = ylim;
xlabel('x', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.075 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

% 创建图例标签
legend_labels = cell(length(theta_list)-1, 1);
for idx = 2:length(theta_list)
    legend_labels{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

% 添加图例（只显示标记点，不显示线条）
legend(h_legend, legend_labels, ...
    'FontName', 'Times New Roman', ...
    'FontAngle', 'italic', ...
    'FontSize', 11, ...
    'Location', 'best', ...
    'Box', 'off');

% 网格线
grid on; grid minor; box off;
set(ax, 'GridLineStyle', ':');

% 处理科学计数法
% 纵坐标
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('×10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 横坐标
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('×10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 11, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

% 提高图形质量
set(gcf, 'Renderer', 'painters');
title('x-Direction Displacement Probability Density', 'FontName', 'Times New Roman', 'FontSize', 12);

%% 图3：y分量的概率密度曲线（跳过θ=0）
fprintf('正在绘制y方向位移的概率密度曲线...\n');
figure('Units', 'inches', 'Position', [0 0 8 6]);

% 存储图例句柄
h_legend = [];

for idx = 2:length(theta_list)
    x_fit = all_y_pdf{idx}(1, :);
    y_fit = all_y_pdf{idx}(2, :);
    
    % 绘制完整的曲线（不带标记）
    plot(x_fit, y_fit, 'Color', colors{idx-1}, 'LineWidth', 1.5);
    hold on;
    
    % 在整个曲线上按间隔添加标记
    marker_indices = 1:marker_interval:length(x_fit);
    marker_handle = plot(x_fit(marker_indices), y_fit(marker_indices), ...
        'Marker', markers{idx-1}, ...
        'MarkerSize', 6, ...
        'MarkerFaceColor', colors{idx-1}, ...
        'MarkerEdgeColor', 'k', ...
        'LineStyle', 'none');
    
    % 将标记点句柄添加到图例句柄数组
    h_legend = [h_legend, marker_handle];
end

hold off;

% 获取当前坐标轴对象
ax = gca;

% 设置横坐标范围
xlim([-1e4, 1e4]);

% 设置坐标轴标签
xlims = xlim;
ylims = ylim;
xlabel('y', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.075 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

% 创建图例标签
legend_labels = cell(length(theta_list)-1, 1);
for idx = 2:length(theta_list)
    legend_labels{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

legend(h_legend, legend_labels, ...
    'FontName', 'Times New Roman', ...
    'FontAngle', 'italic', ...
    'FontSize', 11, ...
    'Location', 'best', ...
    'Box', 'off');

% 网格线
grid on; grid minor; box off;
set(ax, 'GridLineStyle', ':');

% 处理科学计数法
% 纵坐标
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('×10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 横坐标
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('×10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 11, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

% 提高图形质量
set(gcf, 'Renderer', 'painters');
title('y-Direction Displacement Probability Density', 'FontName', 'Times New Roman', 'FontSize', 12);

fprintf('所有图形绘制完成！\n');

%% 辅助函数：高斯核平滑
function smoothed = gaussian_smooth(data, kernel_size, sigma)
    kernel = normpdf(-(kernel_size-1)/2:(kernel_size-1)/2, 0, sigma);
    kernel = kernel / sum(kernel);
    smoothed = conv(data, kernel, 'same');
end