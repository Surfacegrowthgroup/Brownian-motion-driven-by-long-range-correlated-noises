% 清除工作区和命令窗口，避免已有变量干扰
clear; clc;

% 定义不同的 theta 值
theta_list = [0, 0.05, 0.15, 0.25, 0.35, 0.45];

% 调整观测区间，即模拟的时间步数
N = 1000; 
dt = 0.01;
max_lag = N / dt;

% 固定的参数值
Lambda = 30;
a = 6.0;
B = 2.0;

rep = 1000; % 重复次数

% 存储所有 theta 值的概率密度拟合曲线数据
all_pdf_fit = cell(length(theta_list), 1);
all_x_pdf = cell(length(theta_list), 1);
all_y_pdf = cell(length(theta_list), 1);
all_angle_pdf = cell(length(theta_list), 1);
all_x_data = cell(length(theta_list), 1);
all_y_data = cell(length(theta_list), 1);
all_angle_data = cell(length(theta_list), 1);

%% 模拟并存储数据
for idx = 1:length(theta_list)
    all_r = zeros(rep, max_lag); % 存储每次重复的位移距离
    all_x = zeros(rep, max_lag); % 存储每次重复的x坐标
    all_y = zeros(rep, max_lag); % 存储每次重复的y坐标
    all_angles = zeros(rep, max_lag); % 存储每次重复的角度
    
    for repeat_idx = 1:rep
        % 初始化位置向量
        x = zeros(1, max_lag);
        y = zeros(1, max_lag);
        
        % 根据 theta 值选择噪声生成方法
        if theta_list(idx) == 0
            eta_x = sqrt(dt) * randn(1, max_lag);
            eta_y = sqrt(dt) * randn(1, max_lag);
        else
            eta_x = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
            eta_y = fast_fractional_gaussian_noise_matlab(theta_list(idx), max_lag, Lambda, a, B);
        end

        % 计算位置序列
        for i = 2 : max_lag
            x(i) = x(i - 1) + eta_x(i - 1);
            y(i) = y(i - 1) + eta_y(i - 1);
        end
        
        % 计算距离、角度并存储
        all_r(repeat_idx, :) = sqrt(x.^2 + y.^2);
        all_x(repeat_idx, :) = x;
        all_y(repeat_idx, :) = y;
        all_angles(repeat_idx, :) = atan2(y, x);
    end
    
    % 存储所有模拟数据
    all_x_data{idx} = all_x(:);
    all_y_data{idx} = all_y(:);
    all_angle_data{idx} = all_angles(:);
    
    % 处理距离数据并存储拟合曲线
    sampled_r = all_r(:);
    bin_edges = linspace(min(sampled_r), max(sampled_r), 1000); 
    [n, edges] = histcounts(sampled_r, bin_edges, 'Normalization', 'pdf');
    bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    kernel_size = 21; sigma = 3;
    n_smoothed = gaussian_smooth(n, kernel_size, sigma);
    all_pdf_fit{idx} = [bin_centers; n_smoothed];
end

%% 不同θ值下的概率密度曲线
figure;
colors = hsv(length(theta_list)-1);
legend_entries = cell(length(theta_list)-1, 1);

for idx = 2:length(theta_list)  % 从idx=2开始（θ=0.05到0.45）
    x_fit = all_pdf_fit{idx}(1, :);
    y_fit = all_pdf_fit{idx}(2, :);
    plot(x_fit, y_fit, 'Color', colors(idx-1, :), 'LineWidth', 2);
    hold on;
    legend_entries{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

% 坐标轴与标签设置
ax = gca;
xlim([0, 1e4]);

% 标签设置
xlims = xlim;
ylims = ylim;
xlabel('r', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.1 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

legend(legend_entries, 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
grid on; grid minor; box off;
set(ax, 'GridLineStyle', ':');

% 处理科学计数法
% 纵坐标
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('x10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 横坐标
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('x10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 11, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

%% x分量的概率密度曲线
figure;
colors = hsv(length(theta_list)-1);
legend_entries = cell(length(theta_list)-1, 1);

for idx = 2:length(theta_list)
    % 计算并存储x分量的概率密度
    sampled_x = all_x_data{idx};
    bin_edges = linspace(min(sampled_x), max(sampled_x), 1000);
    [n, edges] = histcounts(sampled_x, bin_edges, 'Normalization', 'pdf');
    bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    n_smoothed = gaussian_smooth(n, kernel_size, sigma);
    all_x_pdf{idx} = [bin_centers; n_smoothed];
    
    % 绘制曲线
    plot(bin_centers, n_smoothed, 'Color', colors(idx-1, :), 'LineWidth', 2);
    hold on;
    legend_entries{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

% 坐标轴与标签设置
ax = gca;
xlim([-1e4, 1e4]);

% 标签设置
xlims = xlim;
ylims = ylim;
xlabel('x', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.075 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

legend(legend_entries, 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
grid on; grid minor; box off;
set(ax, 'GridLineStyle', ':');

% 处理科学计数法
% 纵坐标
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('x10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 横坐标
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('x10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 11, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

%% y分量的概率密度曲线
figure;
colors = hsv(length(theta_list)-1);
legend_entries = cell(length(theta_list)-1, 1);

for idx = 2:length(theta_list)
    % 计算并存储y分量的概率密度
    sampled_y = all_y_data{idx};
    bin_edges = linspace(min(sampled_y), max(sampled_y), 1000);
    [n, edges] = histcounts(sampled_y, bin_edges, 'Normalization', 'pdf');
    bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    n_smoothed = gaussian_smooth(n, kernel_size, sigma);
    all_y_pdf{idx} = [bin_centers; n_smoothed];
    
    % 绘制曲线
    plot(bin_centers, n_smoothed, 'Color', colors(idx-1, :), 'LineWidth', 2);
    hold on;
    legend_entries{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

% 坐标轴与标签设置（同x分量）
ax = gca;
xlim([-1e4, 1e4]);

% 标签设置
xlims = xlim;
ylims = ylim;
xlabel('y', 'Position', [xlims(2), -0.075 * diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.075 * diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);

legend(legend_entries, 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
grid on; grid minor; box off;
set(ax, 'GridLineStyle', ':');

% 处理科学计数法
% 纵坐标
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('x10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 横坐标
ax.XAxis.Exponent = 0;
xticks = ax.XTick;
if any(xticks > 0)
    x_exponent = floor(log10(max(xticks(xticks > 0))));
    new_xticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^x_exponent), xticks, 'UniformOutput', false);
    set(ax, 'XTickLabel', new_xticklabels);
    text(xlims(2), 0.05 * diff(ylims), sprintf('x10^{%d}', x_exponent), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 11, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

%% 角度分布的概率密度曲线
figure;
colors = hsv(length(theta_list)-1);
legend_entries = cell(length(theta_list)-1, 1);

for idx = 2:length(theta_list)
    % 计算并存储角度的概率密度
    sampled_angle = all_angle_data{idx};
    bin_edges = linspace(-pi, pi, 50);  % 角度范围[-π, π]
    [n, edges] = histcounts(sampled_angle, bin_edges, 'Normalization', 'pdf');
    bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    n_smoothed = gaussian_smooth(n, kernel_size, sigma);
    all_angle_pdf{idx} = [bin_centers; n_smoothed];
    
    % 绘制曲线
    plot(bin_centers, n_smoothed, 'Color', colors(idx-1, :), 'LineWidth', 2);
    hold on;
    legend_entries{idx-1} = ['\theta = ', num2str(theta_list(idx))];
end

% 坐标轴与标签设置
ax = gca;
xlim([-pi, pi]);
xlims = xlim; ylims = ylim;
xlabel('\phi (rad)', 'Position', [xlims(2), -0.075*diff(ylims), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('pdf', 'Position', [-0.075*diff(xlims), ylims(2), 0], ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
legend(legend_entries, 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
grid on; grid minor; box off;
set(ax, 'GridLineStyle', ':');

% 处理科学计数法
% 纵坐标
ax.YAxis.Exponent = 0;
yticks = ax.YTick;
if any(yticks > 0)
    exponent = floor(log10(max(yticks(yticks > 0))));
    new_yticklabels = arrayfun(@(x) sprintf('%.1f', x / 10^exponent), yticks, 'UniformOutput', false);
    set(ax, 'YTickLabel', new_yticklabels);
    text(0.02 * diff(xlims), ylims(2), sprintf('x10^{%d}', exponent), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top', ...
        'FontSize', 10, 'FontName', 'Times New Roman', 'FontAngle', 'italic');
end

% 坐标轴通过原点
set(ax, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin');

%% 二维联合分布可视化
% θ=0 的二维联合分布
figure('Position', [100, 100, 1200, 500]);
idx = 1;  % θ=0
theta_value = theta_list(idx);

% 随机抽样
sample_size = min(10000, length(all_x_data{idx}));
sample_indices = randperm(length(all_x_data{idx}), sample_size);
x_sample = all_x_data{idx}(sample_indices);
y_sample = all_y_data{idx}(sample_indices);

% 子图1：散点图
subplot(1, 2, 1);
scatter(x_sample, y_sample, 5, 'filled');
title(['\theta = 0 '], 'FontSize', 12);
xlabel('x', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('y', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
axis equal;
box on;
grid on; grid minor;

% 子图2：二维直方图（热图）
subplot(1, 2, 2);
histogram2(x_sample, y_sample, 50, 'Normalization', 'pdf');
xlabel('x', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('y', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
colorbar;
axis equal;
grid on; grid minor;

% θ=0.45 的二维联合分布
figure('Position', [100, 100, 1200, 500]);
idx = 6;  % θ=0.45
theta_value = theta_list(idx);

% 随机抽样
sample_size = min(10000, length(all_x_data{idx}));
sample_indices = randperm(length(all_x_data{idx}), sample_size);
x_sample = all_x_data{idx}(sample_indices);
y_sample = all_y_data{idx}(sample_indices);

% 子图1：散点图
subplot(1, 2, 1);
scatter(x_sample, y_sample, 5, 'filled');
title(['\theta = 0.45'], 'FontSize', 12);
xlabel('x', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('y', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
axis equal;
box on;
grid on; grid minor;

% 子图2：二维直方图（热图）
subplot(1, 2, 2);
histogram2(x_sample, y_sample, 50, 'Normalization', 'pdf');
xlabel('x', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
ylabel('y', 'FontName', 'Times New Roman', 'FontAngle', 'italic', 'FontSize', 11);
colorbar;
axis equal;
grid on; grid minor;

%% 辅助函数：高斯核平滑
function smoothed = gaussian_smooth(data, kernel_size, sigma)
    kernel = normpdf(-(kernel_size-1)/2:(kernel_size-1)/2, 0, sigma);
    kernel = kernel / sum(kernel);
    smoothed = conv(data, kernel, 'same');
end
