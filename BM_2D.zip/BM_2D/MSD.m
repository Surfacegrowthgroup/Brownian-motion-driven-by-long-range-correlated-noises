% 清除工作区和命令窗口
clear; clc;

% 定义参数
theta_list = [0, 0.05, 0.15, 0.25, 0.35, 0.45]; % θ参数列表，控制长程相关性
N = 100000; % 总时间步数
dt = 1; % 时间步长
rep = 100; % 重复次数
max_lag = floor(N/2); % 最大延迟时间

% 画布设置
figure('Units', 'inches', 'Position', [0 0 10 8]);
markers = {'o', 's', '^', 'd', 'v', 'p'}; % 圆形/方形/上三角/菱形/下三角/五边形

colors = {[0 0 0],              % 黑色
          [0 0.45 0.74],        % 蓝色
          [0.85 0.33 0.1],      % 橙色 
          [0.93 0.69 0.13],     % 黄色 
          [0.49 0.18 0.56],     % 紫色 
          [0.47 0.67 0.19]};    % 绿色
all_slopes = zeros(length(theta_list), 2); % 存储斜率结果

% 预分配位移数组
max_displacements = N;

% 存储散点图句柄用于图例
scatter_handles = gobjects(1, length(theta_list));

% 启动计时器
tic;

% 定义共同的横坐标位置（参考线的70%位置）
common_x_pos = log10(max_lag) * 0.7;

% 主循环：遍历不同theta值
for theta_idx = 1:length(theta_list)
    theta = theta_list(theta_idx);
    marker = markers{theta_idx};
    color = colors{theta_idx};
    
    fprintf('正在计算 theta = %.2f ...\n', theta);
    
    % 预分配MSD结果数组
    msd_all = zeros(rep, max_lag);
    
    % 重复模拟循环
    for s = 1:rep
        % 生成分数高斯噪声
        Lambda = 30; % 滤波器参数
        a = 6;
        B = 2;
        
        % 特殊处理theta=0的情况，生成标准高斯噪声
        if theta == 0
            eta_x = sqrt(dt)*randn(1, N);
            eta_y = sqrt(dt)*randn(1, N);
        else
            % 调用分数高斯噪声生成函数
            eta_x = fast_fractional_gaussian_noise_matlab(theta, N, Lambda, a, B);
            eta_y = fast_fractional_gaussian_noise_matlab(theta, N, Lambda, a, B);
        end
        
        % 计算随机游走轨迹
        x = cumsum(eta_x);
        y = cumsum(eta_y);
        %使用欧氏距离计算位移
        r = sqrt(x.^2 + y.^2);
        
        % 计算MSD
        msd = compute_msd(r, max_lag);
        msd_all(s, :) = msd;
    end
    
    % 统计平均MSD
    msd_mean = mean(msd_all, 1);
    
    % 检查是否存在有效数据
    if all(isnan(msd_mean)) || all(msd_mean == 0)
        warning(['theta = ', num2str(theta), ' 的MSD计算结果全为NaN或零']);
        continue;
    end
    
    % 生成时间序列
    t_vals = 1:max_lag;
    
    log_t = log10(t_vals);
    log_msd = log10(abs(msd_mean));
    
    % 分离logt<=2.5和logt>2.5的数据
    idx_small_logt = log_t <= 1.5;  % logt<=1.5的索引
    idx_large_logt = log_t > 1.5;   % logt>1.5的索引
    
    %  绘制logt<=2.5的所有点（保持原有大小）
    if any(idx_small_logt)
        scatter_handles(theta_idx) = scatter(log_t(idx_small_logt), ...
            log_msd(idx_small_logt), 15, color, 'filled', ...
            'Marker', marker, 'MarkerFaceAlpha', 0.6);
        hold on;
    end
    
    % 处理logt>2.5的数据：抽样并放大
    if any(idx_large_logt)
        % 获取logt>2.5的数据
        log_t_large = log_t(idx_large_logt);
        log_msd_large = log_msd(idx_large_logt);
        
        % 设置抽样间隔：每500个点取一个点
        sample_interval = 500;
        
        % 创建抽样索引
        sample_indices = 1:sample_interval:length(log_t_large);
        
        % 绘制抽样点（放大）
        scatter(log_t_large(sample_indices), ...
            log_msd_large(sample_indices), 60, color, 'filled', ...
            'Marker', marker, 'MarkerFaceAlpha', 0.8, ...
            'MarkerEdgeColor', 'k', 'LineWidth', 1.0, 'HandleVisibility', 'off');
        
        % 绘制未抽样的点（保持原大小）
        not_sampled_indices = setdiff(1:length(log_t_large), sample_indices);
        scatter(log_t_large(not_sampled_indices), ...
            log_msd_large(not_sampled_indices), 15, color, 'filled', ...
            'Marker', marker, 'MarkerFaceAlpha', 0.6, 'HandleVisibility', 'off');
    end

    
    % 添加理论参考线
    if theta == 0
        
       % 进行线性拟合 - 使用所有有效数据点
        log_t = log10(t_vals);
        log_msd = log10(abs(msd_mean));
        
        % 去除 NaN 和 Inf 值
        valid_indices = ~isnan(log_t) & ~isinf(log_t) & ~isnan(log_msd) & ~isinf(log_msd);
        valid_log_t = log_t(valid_indices);
        valid_log_msd = log_msd(valid_indices);
        
        % 确保有足够的数据点进行拟合
        min_points = 5;
        if length(valid_log_t) < min_points
            warning('有效数据点不足，无法进行拟合');
            continue;
        end
        
        p = polyfit(valid_log_t, valid_log_msd, 1);
        slope = 1;
        all_slopes(theta_idx, :) = [theta, slope];
        
        % 绘制拟合线 - 使用所有有效数据点拟合，但只显示3.5到4.5的部分
        fit_x_all = valid_log_t; % 所有有效数据点
        fit_y_all = polyval(p, fit_x_all)- 0.25; % 所有有效数据点的拟合值
        
        % 只显示3.5到4.5的部分
        display_indices = fit_x_all >= 3.5 & fit_x_all <= 5.0;
        if any(display_indices)
            plot(fit_x_all(display_indices), fit_y_all(display_indices), 'LineWidth', 1.5, 'Color', 'k', 'LineStyle', '-');
        end
        
         % 在共同横坐标位置显示拟合线斜率
        y_pos = polyval(p, common_x_pos) - 0.5; % 垂直向上偏移
        text(common_x_pos, y_pos, ['\alpha_1 = ', num2str(slope, '%.0f')], ...
            'Color', 'k', 'FontName', 'Times New Roman', 'FontSize', 10, ...
            'HorizontalAlignment', 'center');
    
    % 仅对theta=0.45进行线性拟合
 elseif theta == 0.45
        log_t = log10(t_vals);
        log_msd = log10(abs(msd_mean));
        
        % 去除 NaN 和 Inf 值
        valid_indices = ~isnan(log_t) & ~isinf(log_t) & ~isnan(log_msd) & ~isinf(log_msd);
        valid_log_t = log_t(valid_indices);
        valid_log_msd = log_msd(valid_indices);
        
        % 确保有足够的数据点进行拟合
        min_points = 5;
        if length(valid_log_t) < min_points
            warning('有效数据点不足，无法进行拟合');
            continue;
        end
        
       % 进行线性拟合 - 使用所有有效数据点
        p = polyfit(valid_log_t, valid_log_msd, 1);
        slope = p(1);
        all_slopes(theta_idx, :) = [theta, slope];
        
        % 绘制拟合线 - 使用所有有效数据点拟合，但只显示3.5到4.5的部分
        fit_x_all = valid_log_t; % 所有有效数据点
        fit_y_all = polyval(p, fit_x_all) + 0.25; % 所有有效数据点的拟合值
        
        % 只显示3.5到4.5的部分
        display_indices = fit_x_all >= 3.5 & fit_x_all <= 5.0;
        if any(display_indices)
            plot(fit_x_all(display_indices), fit_y_all(display_indices), 'LineWidth', 1.5, 'Color', 'k', 'LineStyle', '-');
        end
        
        % 在共同横坐标位置显示拟合线斜率
        y_pos = polyval(p, common_x_pos) + 0.5;
        text(common_x_pos, y_pos, ['\alpha_2 = ', num2str(slope, '%.1f')], ...
            'Color', 'k', 'FontName', 'Times New Roman', 'FontSize', 10, ...
            'HorizontalAlignment', 'center');
    end

    % 对其他theta值也进行斜率计算
    if theta < 0.45 && theta > 0
        log_t = log10(t_vals);
        log_msd = log10(abs(msd_mean));
        
        % 去除 NaN 和 Inf 值
        valid_indices = ~isnan(log_t) & ~isinf(log_t) & ~isnan(log_msd) & ~isinf(log_msd);
        valid_log_t = log_t(valid_indices);
        valid_log_msd = log_msd(valid_indices);
        
        % 确保有足够的数据点进行拟合
        min_points = 5;
        if length(valid_log_t) < min_points
            warning('有效数据点不足，无法进行拟合');
            continue;
        end
        
        % 进行线性拟合
        p = polyfit(valid_log_t, valid_log_msd, 1);
        slope = p(1);
        all_slopes(theta_idx, :) = [theta, slope];
    end
end

% 创建图例
legend_entries = cell(1, length(theta_list));
for i = 1:length(theta_list)
    if theta_list(i) == 0
        legend_entries{i} = sprintf('θ = 0');
    else
        legend_entries{i} = sprintf('θ = %.2f', theta_list(i));
    end
end
legend(scatter_handles, legend_entries, 'Location', 'best', ...
    'FontName', 'Times New Roman', 'FontSize', 10);

% 坐标轴设置
xlabel('Log_{10}(t)', 'FontName', 'Times New Roman', 'FontSize', 12, 'FontAngle', 'italic');
ylabel('Log_{10}(\langle|r(t)-r(t_0)|^2\rangle)', 'FontName', 'Times New Roman', 'FontSize', 12, 'FontAngle', 'italic');

set(gca, 'FontName', 'Times New Roman', 'FontSize', 10);
grid off; grid minor; box on;
xlim([log10(1), log10(max_lag)]);

%% 添加小图显示theta与斜率的关系
% 定义小图的位置和大小 [left, bottom, width, height]
inset_pos = [0.6, 0.2, 0.25, 0.25]; 
ax_inset = axes('Position', inset_pos);
hold(ax_inset, 'on'); % 保持绘图状态

% 提取原始6个theta和对应的斜率数据
theta_data = all_slopes(:,1); 
slope_data = all_slopes(:,2); 

% 过滤可能的无效数据
valid_idx = ~isnan(slope_data) & ~isinf(slope_data);
theta_data = theta_data(valid_idx);
slope_data = slope_data(valid_idx);

%  绘制数据点：深蓝色实心三角
scatter(ax_inset, theta_data, slope_data, 100, [0.7 0 0], ...
    'filled', 'Marker', 'v', 'MarkerEdgeAlpha', 0); 

% 仅基于这6个点做最小二乘线性拟合（1阶多项式）
p_fit = polyfit(theta_data, slope_data, 1); 

% 生成拟合线的密集点
theta_fit = linspace(min(theta_data), max(theta_data), 100);
slope_fit = polyval(p_fit, theta_fit);

% 4. 绘制黑色拟合线（线宽1.5）
plot(ax_inset, theta_fit, slope_fit, 'k-', 'LineWidth', 1.5);% 小图坐标轴设置
xlabel(ax_inset, '\theta', 'FontName', 'Times New Roman', 'FontSize', 10, 'FontAngle', 'italic');
ylabel(ax_inset, '\alpha', 'FontName', 'Times New Roman', 'FontSize', 10, 'FontAngle', 'italic');

set(ax_inset, 'FontName', 'Times New Roman', 'FontSize', 8);
grid(ax_inset, 'off'); 
box(ax_inset, 'on');

% 显示总运行时间
total_time = toc;
fprintf('总运行时间: %.2f 秒\n', total_time);

%% MSD计算函数
function msd = compute_msd(x, max_lag)
    N = length(x);
    msd = zeros(1, max_lag);
    
    for lag = 1:max_lag
        len = N - lag;
        % 向量化计算所有位移平方
        displacements(1:len) = (x(1+lag:end) - x(1:end-lag)).^2;
        msd(lag) = mean(displacements);
    end
end