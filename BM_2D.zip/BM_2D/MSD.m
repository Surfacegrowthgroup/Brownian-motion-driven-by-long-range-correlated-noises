% 清除工作区和命令窗口
clear; clc;

% 定义参数
theta_list = [0, 0.05, 0.15, 0.25, 0.35, 0.45]; % θ参数列表，控制长程相关性
N = 1000; % 模拟总时间
dt = 1; % 时间步长
rep = 100; % 重复次数
max_lag = floor(N/2); % 最大延迟时间

% 画布设置
figure('Units', 'inches', 'Position', [0 0 10 8]);
markers = {'o', 's', '^', 'd', 'v', 'p'}; % 不同符号
colors = {[0 0.4470 0.7410], [0.8500 0.3250 0.0980], [0.9290 0.6940 0.1250], ...
          [0.4940 0.1840 0.5560], [0.4660 0.6740 0.1880], 'r'}; % 不同颜色
all_slopes = zeros(length(theta_list), 2); % 存储斜率结果

% 预分配位移数组
max_displacements = N;

% 存储散点图句柄用于图例
scatter_handles = gobjects(1, length(theta_list));

% 启动计时器
tic;

% 定义共同的横坐标位置（参考线的70%位置）
common_x_pos = log10(max_lag) * 0.7;

% 主循环：遍历不同theta值
for theta_idx = 1:length(theta_list)
    theta = theta_list(theta_idx);
    marker = markers{theta_idx};
    color = colors{theta_idx};
    
    fprintf('正在计算 theta = %.2f ...\n', theta);
    
    % 预分配MSD结果数组
    msd_all = zeros(rep, max_lag);
    
    % 重复模拟循环
    for s = 1:rep
        % 生成分数高斯噪声
        Lambda = 30; % 滤波器参数
        a = 6;
        B = 2;
        
        % 特殊处理theta=0的情况，生成标准高斯噪声
        if theta == 0
            eta_x = sqrt(dt)*randn(1, N);
            eta_y = sqrt(dt)*randn(1, N);
        else
            % 调用分数高斯噪声生成函数
            eta_x = fast_fractional_gaussian_noise_matlab(theta, N, Lambda, a, B);
            eta_y = fast_fractional_gaussian_noise_matlab(theta, N, Lambda, a, B);
        end
        
        % 计算随机游走轨迹
        x = cumsum(eta_x);
        y = cumsum(eta_y);
        % 修正：使用欧氏距离计算位移
        r = sqrt(x.^2 + y.^2);
        
        % 计算MSD
        msd = compute_msd(r, max_lag);
        msd_all(s, :) = msd;
    end
    
    % 统计平均MSD
    msd_mean = mean(msd_all, 1);
    
    % 检查是否存在有效数据
    if all(isnan(msd_mean)) || all(msd_mean == 0)
        warning(['theta = ', num2str(theta), ' 的MSD计算结果全为NaN或零']);
        continue;
    end
    
    % 生成时间序列
    t_vals = 1:max_lag;
    
    % 绘制双对数坐标散点图并保存句柄
    scatter_handles(theta_idx) = scatter(log10(t_vals), log10(abs(msd_mean)), 15, color, 'filled', ...
        'Marker', marker, 'MarkerFaceAlpha', 0.6);
    hold on;
    
    % 添加理论参考线 (斜率为1) 并标注
    if theta == 0
        ref_line = plot(log10(t_vals), log10(t_vals), 'k--', 'LineWidth', 1);
        
        % 在共同横坐标位置显示参考线斜率
        y_pos_ref = common_x_pos - 0.2; % 垂直向下偏移
        text(common_x_pos, y_pos_ref, '\alpha = 1', ...
            'Color', 'k', 'FontName', 'Times New Roman', 'FontSize', 10, ...
            'HorizontalAlignment', 'center');
    end
    
    % 仅对theta=0.45进行线性拟合
    if theta == 0.45
        log_t = log10(t_vals);
        log_msd = log10(abs(msd_mean));
        
        % 去除 NaN 和 Inf 值
        valid_indices = ~isnan(log_t) & ~isinf(log_t) & ~isnan(log_msd) & ~isinf(log_msd);
        valid_log_t = log_t(valid_indices);
        valid_log_msd = log_msd(valid_indices);
        
        % 确保有足够的数据点进行拟合
        min_points = 5;
        if length(valid_log_t) < min_points
            warning('有效数据点不足，无法进行拟合');
            continue;
        end
        
        % 进行线性拟合
        p = polyfit(valid_log_t, valid_log_msd, 1);
        alpha = p(1);
        all_slopes(theta_idx, :) = [theta, alpha];
        
        % 绘制拟合线（使用黑色）
        fit_x = log10(t_vals(valid_indices));
        fit_y = polyval(p, fit_x);
        plot(fit_x, fit_y, 'LineWidth', 1.5, 'Color', 'k', 'LineStyle', '--'); % 黑色虚线
        
        % 在共同横坐标位置显示拟合线斜率
        y_pos = polyval(p, common_x_pos) + 0.5; % 垂直向上偏移
        text(common_x_pos, y_pos, ['\alpha = ', num2str(alpha, '%.2f')], ...
            'Color', 'k', 'FontName', 'Times New Roman', 'FontSize', 10, ...
            'HorizontalAlignment', 'center');
    end
end

% 创建图例（使用新罗马字体）
legend_entries = cell(1, length(theta_list));
for i = 1:length(theta_list)
    if theta_list(i) == 0
        legend_entries{i} = sprintf('θ = 0');
    else
        legend_entries{i} = sprintf('θ = %.2f', theta_list(i));
    end
end
legend(scatter_handles, legend_entries, 'Location', 'best', ...
    'FontName', 'Times New Roman', 'FontSize', 10);

% 坐标轴设置
xlabel('Log_{10}(t)', 'FontName', 'Times New Roman', 'FontSize', 12, 'FontAngle', 'italic');
ylabel('Log_{10}(\langle|r(t)-r(t_0)|^2\rangle)', 'FontName', 'Times New Roman', 'FontSize', 12, 'FontAngle', 'italic');

set(gca, 'FontName', 'Times New Roman', 'FontSize', 10);
grid on; grid minor; box on;
xlim([log10(1), log10(max_lag)]);

% 显示总运行时间
total_time = toc;
fprintf('总运行时间: %.2f 秒\n', total_time);

%% MSD计算函数（向量化实现）
function msd = compute_msd(x, max_lag)
    N = length(x);
    msd = zeros(1, max_lag);
    
    for lag = 1:max_lag
        len = N - lag;
        % 向量化计算所有位移平方
        displacements = (x(1+lag:end) - x(1:end-lag)).^2;
        msd(lag) = mean(displacements);
    end
end
